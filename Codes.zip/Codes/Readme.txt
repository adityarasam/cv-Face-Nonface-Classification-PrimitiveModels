T1_V1.1 -- working task 1 module wiith image extraction
T1_V1.2 -- working task 1 with Coariance and Mean displayed images

T1_V1.3 -- working task 1 with Covariance and Mean face -  non face
T1_V1.3 -- working PCA