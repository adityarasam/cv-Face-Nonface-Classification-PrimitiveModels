# -*- coding: utf-8 -*-
"""
Created on Fri Feb  9 20:04:32 2018

@author: adity
"""
counter = 1
print ("Counter: " + str(counter))